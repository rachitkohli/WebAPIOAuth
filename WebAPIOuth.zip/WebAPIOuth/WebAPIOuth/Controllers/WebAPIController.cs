﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebAPIOuth.Controllers
{
    [Authorize]
    public class WebAPIController : ApiController
    {
        public IEnumerable<string> Get()
        {
            return new string[] { "Hello REST API", "I am Authorized buddy!" };
        }

        public string Get(int id)
        {
            return "Hello Authorized API with ID = " + id;
        }
    }
}
